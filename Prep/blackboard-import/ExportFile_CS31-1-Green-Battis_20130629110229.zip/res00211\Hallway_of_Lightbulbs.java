package sample_solution;

import java.util.*;

/**
 * A class to simulate the halway of lightbulbs problem.
 * 
 * Assume that you have an infinitely long hallway with lightbulbs
 * installed regularly every few feet. You also have an infinite number
 * of assistants, each of whom will pass down the hallway in turn. The
 * first assistant will flip the switch for every first lightbulb (all),
 * the second for every second (every other) lightbulb, the third for
 * every third lightbulb, and so forth.
 * 
 * This program will simulate this process and identify the state of
 * a specific lightbulb after a specific number of assistants have passed
 * through the hallway.
 * 
 * @author Seth Battis
 * @version 2008-11-01
 */
public class Hallway_of_Lightbulbs
{
	/**
	 * A generic main method that instantiates the class and executes
	 * our program.
	 */
	public static void main(String[] args)
	{
		Hallway_of_Lightbulbs myHallway = new Hallway_of_Lightbulbs();
	}
	
	/**
	 * The constructor for our class, which does all of the work.
	 */
	public Hallway_of_Lightbulbs()
	{
		/* the scanner collects the user's input from the system console */
		Scanner in = new Scanner (System.in);
		
		/* the light in which we are interested and the number of assistants
		 * to send down the hallway -- we'll get the actual numbers from
		 * user.
		 */
		int lights, assistants;
		
		/* we'll represent the lightbulbs as booleans: true means that
		 * the lightbulb is on, false that the bulb is off. Happily, we
		 * only need to track the first few lightbulbs -- only up to the
		 * one that the the user has asked about (which we'll find out
		 * in a moment).
		 */
		boolean hallway[];
		
		System.out.print ("Which light bulb? ");
		lights = in.nextInt();
		
		/* decide how many lightbulbs to have in our simulation, if the
		 * user requests fewer than 20 lightbulbs, we'll still have at
		 * least 20 for a visually compelling output at the end of the
		 * program
		 */
		if (lights < 20)
		{
			hallway = new boolean[20];
		}
		else
		{
			hallway = new boolean[lights];
		}
		
		/* turn off all the lights in the hallway */
		for (int i = 0; i < hallway.length; i++)
		{
			hallway[i] = false;
		}
			
		System.out.print ("How many assistants? ");
		assistants = in.nextInt();
		
		/* send the assistants down the hallway one at a time */
		for (int a = 0; a < assistants; a++)
		{
			/* each assistant should only toggle the lightbulbs for
			 * which their number is a factor
			 * 
			 * N.B. that we are numbering our assistants starting at 1,
			 * rather than the Java/C standard of zero, for usability
			 * by normal human beings (hence, a + 1).
			 */
			for (int l = a; l < hallway.length; l += (a + 1))
			{
				hallway[l] = !hallway[l];
			}
		}
		
		/* print out a display of the first 20 lightbulbs for visual
		 * effect
		 */
		for (int i = 0; (i < hallway.length) && (i < 20); i++)
		{
			if (hallway[i])
			{
				System.out.print ("O ");
			}
			else
			{
				System.out.print ("- ");
			}
		}
		System.out.println();
		
		/* answer the user's original question */
		System.out.println ("The " + lights + "th lightbulb is " + (hallway[lights-1] ? "on" : "off"));
	}
}
