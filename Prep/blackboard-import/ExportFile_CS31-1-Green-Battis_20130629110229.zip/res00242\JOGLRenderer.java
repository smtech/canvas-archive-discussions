/* import some libraries to handle events and make OpenGL easier */
import java.awt.event.KeyEvent;
import simplerjogl.*;

public class JOGLRenderer extends Renderer
{
	/* an array of chesspieces */
	private ChessPiece pawns[];
	private Light sun;
	
	public void init()
	{
		/* initialize and instantiate our array so that each chess piece
		 * is at a different location */
		pawns = new ChessPiece[8];
		for (int i = 0; i < pawns.length; i++)
		{
			pawns[i] = new ChessPiece (gl, glut, 1.25f, (i - 4) * 2, 0);
		}
		
		/* but wait, we're going to substitute a Rook for a generic
		   ChessPiece at index 3. And we can do this, because a Rook is
		   a sub class of a ChessPiece, which means that it _is_ a
		   ChessPiece -- just a special kind of ChessPiece. */
		pawns[3] = new Rook (gl, glut, 3, -2, 0);
		
		sun = new Light (gl);
		sun.enable();
	}
	
	/**
	 * draw all our chess pieces
	 */
	public void display()
	{
		glu.gluLookAt(0, 0, 15f,	// eye location
					  0, 0, 0,	// focal point
					  0, 1, 0);	// up vector
		for (int i = 0; i < pawns.length; i++)
		{
			pawns[i].draw();
		}
	}
	
	/**
	 * translate numeric keys into array indices and move the chess
	 * piece at that index to a new location. Note that this is
	 * wildly unsafe, as it is _easy_ to type keys which will generate
	 * IndexOutOfBounds exceptions. This should be fixed!
	 */
	public void keyTyped (KeyEvent e)
	{
		/* convert the key typed from an Unicode character to an index,
		   as we did in Caesar Cipher */
		pawns[(int) e.getKeyChar() - (int) '0'].move((int) e.getKeyChar() - (int) '0', 2);
	}
}
