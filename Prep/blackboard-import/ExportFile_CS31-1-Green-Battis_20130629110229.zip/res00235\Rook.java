/* import some handy libraries to do OpenGL rendering */
import javax.media.opengl.GL;
import com.sun.opengl.util.GLUT;

/* define a Rook as a subclass of the ChessPiece superclass */
public class Rook extends ChessPiece
{
	/**
	 * The rook constructor is simply a pass-through: it passes its
	 * parameters through to the superclass's (ChessPiece's)
	 * constructor to do whatever setup needs to be done. It is also
	 * possible (and reasonable) for a subclass' constructor to do
	 * more in addition to (but not usually instead of) calling
	 * a constructor from the superclass. It is also worth noting that
	 * the subclass' constructor might call a constructor in the
	 * superclass with different parameters than it itself has -- since
	 * part of the extension might involve storing additional information
	 * beyond the scope of the superclass.
	 */
	public Rook (GL gl, GLUT glut, float height, float x, float z)
	{
		super (gl, glut, height, x, z);
	}
	
	/**
	 * override the superclass' cap() method with our own. Note that our
	 * draw method (which is inherited from the superclass and therefore
	 * does not need to be redefined), correctly calls our version of the
	 * cap() method and not the superclass' version of the cap method.
	 */
	public void cap()
	{
		gl.glPushMatrix();
			gl.glTranslatef (0, height + 0.4f, 0);
			glut.glutSolidTeapot (0.45f);
		gl.glPopMatrix();
	}
}
