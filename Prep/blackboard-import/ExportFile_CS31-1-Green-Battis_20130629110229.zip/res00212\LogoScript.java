
package sample_solution;

import java.awt.event.*;

import logo.*;

/**
 * A simple simulation of Conway's Game of Life. (This version just allows
 * for organisms to move randomly around the screen -- no eating, dying or
 * reproducing).
 * 
 * @author Seth Battis
 * @version 2008-11-23
 */
public class LogoScript extends LogoRenderer
{
	/*
	 * hand off all of the Organism management to a Map object -- the
	 * LogoScript object will really just be handling user interface
	 * actions
	 */
	private Map	m;

	/* initialize variables and give the user some instructions */
	public void script ()
	{
		/*
		 * note that we tell the Map that we want to use _this_ LogoScript
		 * object -- the one we're in right now -- as the target for all
		 * drawing commands by Organisms. Oh, and that we want 1000
		 * Organisms on the map.
		 */
		m = new Map (this, 1000);
		m.draw ();
		shell.println ("Press any key to simulate life.");
	}

	/**
	 * Handle any key press by advancing the animation one frame
	 * 
	 * @param e
	 *            information about the keyPressed event
	 * @see simplerjogl.Renderer#keyPressed(java.awt.event.KeyEvent)
	 */
	public void keyPressed (KeyEvent e)
	{
		m.move ();
		reset ();
		m.draw ();
	}
}
