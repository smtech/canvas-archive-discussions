/* import some useful libraries so that we can use OpenGL */
import javax.media.opengl.GL;
import com.sun.opengl.util.GLUT;

public class ChessPiece
{
	/* our data fields, starting with the gl and glut objects which are
	   references to the main gl and glut objects that handle our 3D
	   rendering. */
	protected GL gl;
	protected GLUT glut;
	
	/* a chess piece knows how tall it is, where it is on the board, and
	   where it should be moving to on the board (a destination) */
	protected float height;
	protected float x, z;
	protected float destX, destZ;
	
	/**
	 * A constructor which updates our gl and glut data fields to be
	 * references to the main gl and glut objects, and stores the desired
	 * height and location into our data fields
	 */
	public ChessPiece (GL gl, GLUT glut, float height, float x, float z)
	{
		/* note the use of "this" to refer to "this instance of the
		   ChessPiece class" */
		this.gl = gl;
		this.glut = glut;
		
		this.height = height;
		this.x = x;
		this.z = z;
		
		/* initialize the destination as where we are to prevent
		   unexpected movement */
		this.destX = x;
		this.destZ = z;
	}
	
	/**
	 * A method to draw the chess piece in the OpenGL environment
	 */
	public void draw()
	{
		/* if we're not at the destination, move toward it */
		if (x != destX)
		{
			if (x > destX)
			{
				x -= 0.25f;
			}
			else
			{
				x += 0.25f;
			}
		}
		
		/* likewise, move along the Z-axis as well as the X-axis */
		if (z != destZ)
		{
			if (z > destZ)
			{
				z -= 0.25f;
			}
			else
			{
				z += 0.25f;
			}
		}
		
		/* draw the chess piece */
		gl.glPushMatrix();
			gl.glTranslatef (x, -1, z);
			gl.glPushMatrix();
				gl.glRotatef (90, -1, 0, 0);
				glut.glutSolidCylinder (0.8f, 0.1f, 20, 20);
				glut.glutSolidCone(0.8f, 1, 20, 20);
				glut.glutSolidCylinder (0.3f, height, 20, 20);
			gl.glPopMatrix();
			gl.glPushMatrix();
				gl.glTranslatef (0, height, 0);
				gl.glRotatef (90, -1, 0, 0);
				glut.glutSolidTorus(0.1f, 0.30f, 20, 20);
			gl.glPopMatrix();
			cap(); // added for convenience in extensions
		gl.glPopMatrix();
	}
	
	/**
	 * This method allows us to extend the ChessPiece and change its
	 * appearance simply by swapping in a new "cap" at the top of the
	 * chess piece model */
	public void cap()
	{
		gl.glPushMatrix();
			gl.glTranslatef (0, height + 0.4f, 0);
			glut.glutSolidSphere (0.45f, 20, 20);
		gl.glPopMatrix();
	}
	
	/**
	 * movement is simply setting a destination -- every time that we
	 * draw the chess piece, we will attempt to move towards the
	 * destination
	 */
	public void move (float x, float z)
	{
		destX = x;
		destZ = z;
	}
}