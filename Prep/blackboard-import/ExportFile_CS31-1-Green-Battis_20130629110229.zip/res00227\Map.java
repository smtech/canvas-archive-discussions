
package sample_solution;

/**
 * A "map" of all the organisms in our simplified Conway simulation -- in
 * this case, really just a roster of all the organisms that we're working
 * with.
 * 
 * @author Seth Battis
 * @version 2008-11-23
 */
public class Map
{
	/* an array of organisms that are being drawn on the screen */
	private Organism	roster[];

	/**
	 * The constructor -- set up the map so that it's ready to go: figure
	 * out where we're drawing (which LogoScript object) and generate as
	 * many organisms as have been requested.
	 * 
	 * @param l
	 *            the LogoScript object that will be handling the drawing
	 *            for us
	 * @param numOrgs
	 *            the number of organisms that we should generate
	 */
	public Map (LogoScript l, int numOrgs)
	{
		roster = new Organism[numOrgs];
		for (int i = 0; i < roster.length; i++ )
		{
			/*
			 * note that we don't actually store a reference to the
			 * LogoScript object in our Map object -- we receive it as a
			 * parameter just so that we can pass it to the Organisms for
			 * _their_ reference. (The map doesn't care about the
			 * LogoScript object: it doesn't directly draw anything. It
			 * just tells the Organisms to draw!)
			 */
			roster[i] = new Organism (l);
		}
	}

	/**
	 * Draw all of the organisms in our roster at their present locations
	 */
	public void draw ()
	{
		for (int i = 0; i < roster.length; i++ )
		{
			roster[i].draw ();
		}
	}

	/**
	 * Tell every organism on our roster to move itself
	 */
	public void move ()
	{
		for (int i = 0; i < roster.length; i++ )
		{
			roster[i].move ();
		}
	}
}
