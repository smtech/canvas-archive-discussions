
package sample_solution;

/**
 * Keep track of a single organism in our simplified Conway simulation:
 * where it is, what color it is, which LogoScript window to draw it in.
 * 
 * @author Seth Battis
 * @version 2008-11-23
 */
public class Organism
{
	/* the location of the organism on the screen, in drawing coordinates */
	private int			x, y;
	/* the color of the organism */
	private int			r, g, b;
	/* which LogoScript window this organism should be drawn in */
	private LogoScript	logo;

	/**
	 * The constructor, which randomly generates new locations and colors
	 * for Organisms (using the regenerate() method). Note that the
	 * LogoScript parameter is saved for future use -- for whenever we need
	 * to draw the Organism
	 * 
	 * @param logo
	 *            the LogoScript object where this organism should be drawn
	 * @see #regenerate()
	 */
	public Organism (LogoScript logo)
	{
		/*
		 * note that this.logo is the private LogoScript data field
		 * declared above, while logo is just the LogoScript parameter to
		 * this constructor: we are storing the parameter's value into our
		 * datafield for future reference!
		 */
		this.logo = logo;
		/*
		 * pass off all the hard work to a helper function -- which we'll
		 * use again later!
		 */
		regenerate ();
	}

	/**
	 * Randomly generate a location and color for a new Organism
	 */
	private void regenerate ()
	{
		x = (int) ( (Math.random () * 800) - 400);
		y = (int) ( (Math.random () * 600) - 300);
		r = (int) (Math.random () * 255);
		g = (int) (255 - (r + Math.random () * 255));
		b = 255 - (r + g);
	}

	/**
	 * Move an organism in a random direction (pick a random number to
	 * represent a direction, then increment its coordinates to move it in
	 * that direction). If the Organism moves off-screen it "dies" and is
	 * regenerated.
	 * 
	 * @see #regenerate()
	 */
	public void move ()
	{
		/* pick a random direction */
		int choice = (int) (Math.random () * 4);
		/*
		 * a switch statement is like a lot of if...else statements stacked
		 * together... more or less
		 */
		switch (choice)
		{
			case 0: /* right */
				x += 1;
				break;
			case 1: /* left */
				x -= 1;
				break;
			case 2: /* up */
				y += 1;
				break;
			case 3: /* down */
				y -= 1;
				break;
		}
		/*
		 * did we go out of bounds? if so, arise from our ashes like a
		 * phoenix, in a new location on the screen
		 */
		if ( (-400 > x) || (x > 400) || (-300 > y) || (y > 300))
		{
			regenerate ();
		}
	}

	/**
	 * Draw the organism in its Logo window. Organisms are just colored
	 * boxes.
	 */
	public void draw ()
	{
		logo.penUp ();
		logo.penColor (r, g, b);
		logo.heading (0);
		logo.move (x - 2, y - 2);
		logo.penDown ();
		for (int i = 0; i < 4; i++ )
		{
			logo.forward (5);
			logo.turnRight (90);
		}
	}
}
