import java.awt.event.KeyEvent;

public class LogoScript extends LogoRenderer
{
	private Organism allMyCritters[];
	
	public void script()
	{
		allMyCritters = new Organism[500];
		for (int i = 0; i < allMyCritters.length; i++)
		{
			allMyCritters[i] = new Organism (this);
			allMyCritters[i].draw();
		}
	}
	
	public void keyPressed (KeyEvent e)
	{
		reset();
		for (int i = 0; i < allMyCritters.length; i++)
		{
			allMyCritters[i].move();
			allMyCritters[i].draw();
		}
	}
}
