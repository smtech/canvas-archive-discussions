public class Organism
{
	// information stored in data fields
	private int x, y;
	private LogoScript logo;
	
	public Organism (LogoScript newLogo)
	{
		logo = newLogo;
		x = 3; // this might be a good place for Math.random()
		y = (int) ((Math.random() * 580) - 290);
	}
	
	// actions which are methods that work with that data
	public void draw()
	{
		logo.penUp();
		logo.move (x, y);
		logo.penDown();
		
		for (int i = 0; i < 4; i ++)
		{
			logo.forward (10);
			logo.turnRight (90);
		}
	}
	
	public void move()
	{
		x += 1;
	}
}
