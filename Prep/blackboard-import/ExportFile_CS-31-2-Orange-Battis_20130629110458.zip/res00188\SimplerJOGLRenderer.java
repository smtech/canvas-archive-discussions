package orange.Fingers;
import java.awt.event.KeyEvent;

import simplerjogl.*;

/**
 * Generic SimplerJOGL rendering canvas
 * 
 * @author Seth Battis
 * @version 2009-01-07
 */
public class SimplerJOGLRenderer extends Renderer
{
	private Finger hand[];
	private Finger thumb;
	private Light l;

	public void init ()
	{
		l = new Light (gl);
		l.enable();
		
		hand = new Finger[4];
		for (int i = 0; i < hand.length; i++)
		{
			hand[i] = new Finger (gl, 1 - (i * 0.1));
		}
		thumb = new Finger (gl, .5);
	}

	public void display ()
	{
		/* set the location and focal point of our camera */
		glu.gluLookAt (-15, 0, 0, 0, 0, 0, 0, 1, 0);

		for (int i = 0; i < hand.length; i++)
		{
			gl.glPushMatrix();
			{
				gl.glTranslated (0, 0, i);
				hand[i].draw();
			}
			gl.glPopMatrix();
		}
		gl.glRotated (90, -1, 0, 0);
		gl.glRotated (90, 0, -1, 0);
		thumb.draw();
	}

	public void keyTyped (KeyEvent e)
	{
		for (int i = 0; i < hand.length; i++)
		{
			hand[i].bend (e);
		}
		thumb.bend (e);
	}
}