package orange.Fingers;

import java.awt.event.KeyEvent;

import javax.media.opengl.GL;

import simplerjogl.Model;

public class Finger extends Model
{
	private FingerJoint joint1, joint2, joint3;
	
	public Finger (GL gl, double size)
	{
		super(gl);
		joint1 = new FingerJoint (gl, 1 * size);
		joint2 = new FingerJoint (gl, 1.25 * size);
		joint3 = new FingerJoint (gl, 1.25 * size);
	}
	
	public void draw()
	{
		joint3.draw();
		joint2.draw ();
		joint1.draw();
	}
	
	public void bend (KeyEvent e)
	{
		joint1.bend (e);
		joint2.bend (e);
		joint3.bend (e);
	}
}
