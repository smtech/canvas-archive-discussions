package orange.Fingers;

import java.awt.event.*;

import javax.media.opengl.GL;

import simplerjogl.*;

public class FingerJoint extends Model
{
	private double size;
	private double bend;

	public FingerJoint (GL gl, double size)
	{
		super (gl);
		this.size = size;
		bend = 0;
	}

	public void draw()
	{
		green.use ();
		gl.glRotated (bend, 0, 0, 1);
		gl.glPushMatrix();
		{
			gl.glRotated (90, -1, 0, 0);
			glut.glutSolidCylinder (.5, size, 20, 20);
			glut.glutSolidSphere (.5, 20, 20);
		}
		gl.glPopMatrix();
		gl.glTranslated (0, size, 0);
		glut.glutSolidSphere (.5, 20, 20);
	}

	public void bend (KeyEvent e)
	{
		if (e.getKeyChar() == 'b')
		{
			if (bend < 90)
			{
				bend++;
			}
		}

		if (e.getKeyChar() == 'u')
		{
			if (bend > 0)
			{
				bend--;
			}
		}
	}
}
