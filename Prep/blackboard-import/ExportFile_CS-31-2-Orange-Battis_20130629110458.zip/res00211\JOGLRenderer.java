import simplerjogl.*;

public class JOGLRenderer extends Renderer
{
	private double degreesToRotate;
	
	public void init()
	{
		degreesToRotate = 90;
	}
	
	public void display()
	{
		glu.gluLookAt (0, 0, 10, // location of the camera's eye
					   0, 0, 0,  // what the camera's pointed at
					   0, 1, 0); // up vector
		
		glut.glutWireTeapot (1);

		gl.glTranslated (2, 0, 0);
		gl.glRotated (degreesToRotate, 1, 0, 0);
		gl.glScaled (1, 3, 1);
		glut.glutWireSphere (1, 10, 10);
		
		degreesToRotate += 15;
	}
}
