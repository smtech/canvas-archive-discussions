package orange.Fingers;
import simplerjogl.*;

/**
 * Main class for a generic SimplerJOGL application
 * 
 * @author Seth Battis
 * @version 2009-01-07
 */
public class SimplerJOGLApp
{
	public static void main (String[] args)
	{
		/* instantiate the SimplerJOGL canvas */
		Renderer renderer = new SimplerJOGLRenderer ();

		/* instantiate a window to hold the canvas */
		Frame frame = Frame.createFrame ("SimplerJOGL App", false);

		/*
		 * bind the canvas to the window's event loop, listening for GL
		 * display events
		 */
		frame.addGLEventListener (renderer);
		frame.addKeyListener (renderer);

		/* display the window (and canvas) */
		frame.start ();
	}
}